<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Models\Property;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class PropertyController extends Controller
{

    public function index()
    {
       
        $properties = Property::with(['community', 'offer'])->paginate(5);
        return [
            'status' => 200,
            'message' => __('messages.properties'),
            'data' => $properties,
        ];
    }


    public function show($id)
    {
        $properties = Property::with(['community', 'offer'])->first();


        return [
            'status' => 200,
            'message' => __('messages.properties'),
            'data' => $properties,
        ];
    }

    public function Status($status)
    {
        $properties = Property::with('community')->where('status', $status)->get();
        return [
            'status' => 200,
            'message' => __('messages.properties'),
            'data' => $properties,
        ];
    }
    public function type($offer_type)
    {
        $properties = Property::with('community')->where('offer_type', $offer_type)->get();
        return [
            'status' => 200,
            'message' => __('messages.properties'),
            'data' => $properties,
        ];
    }

    public function shortTerm($short)
    {
        $properties = Property::where('is_shortterm', $short)->get();
        return [
            'status' => 200,
            'message' => __('messages.properties'),
            'data' => $properties,
        ];
    }
}
